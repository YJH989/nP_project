public class City {
	String cityName;
	int x;
	int y;
	int landPrice;
	int villaPrice;
	int buildingPrice;
	int hotelPrice;
	boolean playerGetBuilding;
	boolean canBuy = true;
	String owner;
	String goldenKeyDetails[] = {"�л�ȸ���Լ� ", "�����Բ� ", "���⿡�� ", "���迡�� ", "�Ĺ迡�� "};
	String goldenKeyDetails2[] = {"���� �޾ҽ��ϴ�!", "���� ������ϴ�!"};
	String goldenKeyDetail;
	int goldenKeyPrice;
	
	public City(String cityName, int x, int y, int villaPrice, int buildingPrice, int hotelPrice) {
		this.cityName = cityName;
		this.x = x;
		this.y = y;
		this.villaPrice = villaPrice;
		this.buildingPrice = buildingPrice;
		this.hotelPrice = hotelPrice;
	}
	public String getCityName() {
		return cityName;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	
	public boolean isPlayerGetBuilding() {
		return playerGetBuilding;
	}

	public void setPlayerGetBuilding(boolean playerGetBuilding) {
		this.playerGetBuilding = playerGetBuilding;
	}

	public boolean isCanBuy() {
		return canBuy;
	}

	public void setCanBuy(boolean canBuy) {
		this.canBuy = canBuy;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	public void setVillaPrice(int villaPrice) {
		this.villaPrice = villaPrice;
	}
	
	public int getVillaPrice() {
		return villaPrice;
	}
	
	public void setBuildingPrice(int buildingPrice) {
		this.buildingPrice = buildingPrice;
	}
	
	public int getBuildingPrice() {
		return buildingPrice;
	}
	
	public void setHotelPrice(int hotelPrice) {
		this.hotelPrice = hotelPrice;
	}
	
	public int getHotelPrice() {
		return hotelPrice;
	}
	
	public void setLandPrice(int landPrice) {
		this.landPrice = landPrice;
	}
	
	public int getLandPrice() {
		return landPrice;
	}
	
	public void setGoldenKeyDetail(int GoldenKeyDetail) {
		this.goldenKeyDetail = goldenKeyDetails[GoldenKeyDetail%5] + this.goldenKeyPrice + goldenKeyDetails2[GoldenKeyDetail%2];
	}
	
	public String getGoldenKeyDetail() {
		return goldenKeyDetail;
	}
	
	public void setGoldenKeyPrice(int goldenKeyPrice) {
		this.goldenKeyPrice = goldenKeyPrice;
	}
	
	public int getGoldenKeyPrice() {
		return goldenKeyPrice;
	}
	
}
