// JavaChatClientMain.java
// Java Client ����import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.awt.event.ActionEvent;
import java.awt.Image;
import java.awt.Graphics;

public class GameMain extends JFrame { //����ȭ��

   private JPanel contentPane;
   private JButton btnStart;
   private JButton btnSetting;
   private JButton btnLeave;
   
   private int i = 1;
   ImageIcon icon;

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               GameMain frame = new GameMain();
               frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   /**
    * Create the frame.
    */
   public GameMain() {
      icon = new ImageIcon("bgimg.png");
        
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 900, 600);
      setResizable(false);
      contentPane = new JPanel(){
            public void paintComponent(Graphics g) {
               g.drawImage(icon.getImage(), 0, 0, null);
                setOpaque(false);
                super.paintComponent(g);
            }
        };;
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      setContentPane(contentPane);
      contentPane.setLayout(null);
      
      btnStart = new JButton();
      ImageIcon btnStartIcon = new ImageIcon("btnStart.png");
      btnStart.setIcon(btnStartIcon);
      btnStart.setBounds(50, 350, 192, 42);
      contentPane.add(btnStart);
      Myaction action = new Myaction();
      btnStart.addActionListener(action);
      
      btnSetting = new JButton();
      ImageIcon btnSettingIcon = new ImageIcon("btnSetting.png");
      btnSetting.setIcon(btnSettingIcon);
      btnSetting.setBounds(50, 400, 192, 42);
      contentPane.add(btnSetting);
      
      btnLeave = new JButton();
      ImageIcon btnLeaveIcon = new ImageIcon("btnLeave.png");
      btnLeave.setIcon(btnLeaveIcon);
      btnLeave.setBounds(50, 450, 192, 42);
      contentPane.add(btnLeave);
   
      btnSetting.addActionListener(action);
      btnLeave.addActionListener(action);
   }
   
   class Myaction implements ActionListener // ����Ŭ������ �׼� �̺�Ʈ ó�� Ŭ����
   {
      @Override
      public void actionPerformed(ActionEvent e) {
         if (e.getSource() == btnStart) {
            String username = "User";
            String ip_addr = "127.0.0.1";
            String port_no = "30000";
            
            GameView view = new GameView(username + i, ip_addr, port_no);
            setVisible(false);
         }
         
//         if (e.getSource() == btnChNick) {
//            if(i <= 4) i++;
//            else i = 1;
//         }
         
         if (e.getSource() == btnSetting) {
            //setting �ڵ�
         }
         
         if (e.getSource() == btnLeave) {
            System.exit(0);
         }
      }
   }
}