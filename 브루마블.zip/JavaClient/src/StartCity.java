public class StartCity extends City{
	public StartCity(String cityName, int x, int y, int villaPrice, int buildingPrice, int hotelPrice) {
		super(cityName, x, y, villaPrice, buildingPrice, hotelPrice);
		super.setOwner("�����Ұ���");
		super.setCanBuy(false);
	}
}
