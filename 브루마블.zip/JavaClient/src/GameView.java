import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class GameView extends JFrame {
	private JPanel contentPane;
	private JTextField txtInput;
	private String UserName;
	private JButton btnSend;
	private JButton btnRoll;
	private JButton btnLeave;
	private JButton btnChBg;
	private JTextArea textArea;
	private static final  int BUF_LEN = 128; //  Windows ó�� BUF_LEN �� ����
	private Socket socket; // �������
	private InputStream is;
	private OutputStream os;
	private DataInputStream dis;
	private DataOutputStream dos;
	private JLabel lblUserName[] = new JLabel[4];
	private JLabel usersMoney[] = new JLabel[4];
	private JLabel usersCard[] = new JLabel[4];
	private JLabel usersIcon[] = new JLabel[4];
	private JLabel usersSmallIcon[] = new JLabel[4];
	private JLabel user1Building[][] =  new JLabel[3][20];
	private JLabel user2Building[][] =  new JLabel[3][20];
	private JLabel user3Building[][] =  new JLabel[3][20];
	private JLabel user4Building[][] =  new JLabel[3][20];
	private JLabel dice1;
	private JLabel dice2;
	private JButton buyVilla;
	private JLabel buyVillaPrice;
	private JButton buyBuilding;
	private JLabel buyBuildingPrice;
	private JButton buyHotel;
	private JLabel buyHotelPrice;
	private JButton buyCancel;
	private int userCnt = 1;
	private int bgCnt = 0;
	private int building1Cnt = 0;
	private int building2Cnt = 0;
	private int building3Cnt = 0;
	private int building4Cnt = 0;
	
	CityLocation cityLocation = new CityLocation();
	City location = cityLocation.getCity(0);
	
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	

	private Frame frame;
	private FileDialog fd;
	
	/**
	 * Create the frame.
	 */
	public GameView(String username, String ip_addr, String port_no) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		setResizable(false);
		contentPane = new JPanel(){
            public void paintComponent(Graphics g) {
        		Image bgImg = new ImageIcon("mapDefault.png").getImage();
                g.drawImage(bgImg, 0, 0, null);
                setOpaque(false);
                super.paintComponent(g);
            }
        };
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 425, 540, 80);
		contentPane.add(scrollPane);

		textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);

		txtInput = new JTextField();
		txtInput.setBounds(25, 510, 450, 40);
		contentPane.add(txtInput);
		txtInput.setColumns(10);

		btnSend = new JButton("Send");
		btnSend.setBounds(485, 510, 76, 40);
		contentPane.add(btnSend);
		
		lblUserName[0] = new JLabel("Name");
		lblUserName[0].setBounds(650, 30, 67, 40);
		lblUserName[0].setForeground(Color.WHITE);
		//contentPane.add(lblUserName[0]);
		setVisible(true);
		
		lblUserName[1] = new JLabel("Name2");
		lblUserName[1].setBounds(650, 130, 67, 40);
		lblUserName[1].setForeground(Color.WHITE);
		//contentPane.add(lblUserName[1]);
		
		lblUserName[2] = new JLabel("Name3");
		lblUserName[2].setBounds(650, 230, 67, 40);
		lblUserName[2].setForeground(Color.WHITE);
		//contentPane.add(lblUserName[2]);
		
		lblUserName[3] = new JLabel("Name4");
		lblUserName[3].setBounds(650, 330, 67, 40);
		lblUserName[3].setForeground(Color.WHITE);
		//contentPane.add(lblUserName[3]);
		
		usersMoney[0] = new JLabel("�ڻ�: 0");
		usersMoney[0].setBounds(650, 45, 100, 40);
		usersMoney[0].setForeground(Color.WHITE);
		//contentPane.add(usersMoney[0]);
		
		usersMoney[1] = new JLabel("�ڻ�: 0");
		usersMoney[1].setBounds(650, 145, 100, 40);
		usersMoney[1].setForeground(Color.WHITE);
		//contentPane.add(usersMoney[1]);
		
		usersMoney[2] = new JLabel("�ڻ�: 0");
		usersMoney[2].setBounds(650, 245, 100, 40);
		usersMoney[2].setForeground(Color.WHITE);
		//contentPane.add(usersMoney[2]);
		
		usersMoney[3] = new JLabel("�ڻ�: 0");
		usersMoney[3].setBounds(650, 345, 100, 40);
		usersMoney[3].setForeground(Color.WHITE);
		//contentPane.add(usersMoney[3]);
		
		usersCard[0] = new JLabel("card//");
		usersCard[0].setBounds(650, 60, 150, 40);
		usersCard[0].setForeground(Color.RED);
		//contentPane.add(usersCard[0]);
		
		usersCard[1] = new JLabel("card//");
		usersCard[1].setBounds(650, 160, 150, 40);
		usersCard[1].setForeground(Color.RED);
		//contentPane.add(usersCard[1]);
		
		usersCard[2] = new JLabel("card//");
		usersCard[2].setBounds(650, 260, 150, 40);
		usersCard[2].setForeground(Color.RED);
		//contentPane.add(usersCard[2]);
		
		usersCard[3] = new JLabel("card//");
		usersCard[3].setBounds(650, 360, 150, 40);
		usersCard[3].setForeground(Color.RED);
		//contentPane.add(usersCard[3]);
		
		usersIcon[0] = new JLabel();
		Image user1Icon = new ImageIcon("user1.png").getImage();
        Image user1Img = user1Icon.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        usersIcon[0].setIcon(new ImageIcon(user1Img));
		usersIcon[0].setBounds(780, 30, 80, 80);
		//contentPane.add(usersIcon[0]);
		
		usersIcon[1] = new JLabel();
		Image user2Icon = new ImageIcon("user2.png").getImage();
        Image user2Img = user2Icon.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        usersIcon[1].setIcon(new ImageIcon(user2Img));
		usersIcon[1].setBounds(780, 130, 80, 80);
		//contentPane.add(usersIcon[1]);
		
		usersIcon[2] = new JLabel();
		Image user3Icon = new ImageIcon("user3.png").getImage();
        Image user3Img = user3Icon.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        usersIcon[2].setIcon(new ImageIcon(user3Img));
		usersIcon[2].setBounds(780, 230, 80, 80);
		//contentPane.add(usersIcon[2]);
		
		usersIcon[3] = new JLabel();
		Image user4Icon = new ImageIcon("user4.png").getImage();
        Image user4Img = user4Icon.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        usersIcon[3].setIcon(new ImageIcon(user4Img));
		usersIcon[3].setBounds(780, 330, 80, 80);
		//contentPane.add(usersIcon[3]);
		
		usersSmallIcon[0] = new JLabel();
		Image users1SmallIcon = new ImageIcon("user1.png").getImage();
        Image users1SmallImg = users1SmallIcon.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        usersSmallIcon[0].setIcon(new ImageIcon(users1SmallImg));
        usersSmallIcon[0].setBounds(500, 30, 40, 40);
		//contentPane.add(usersSmallIcon[0]);
		
		usersSmallIcon[1] = new JLabel();
		Image users2SmallIcon = new ImageIcon("user2.png").getImage();
        Image users2SmallImg = users2SmallIcon.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        usersSmallIcon[1].setIcon(new ImageIcon(users2SmallImg));
        usersSmallIcon[1].setBounds(500, 30, 40, 40);
		//contentPane.add(usersSmallIcon[1]);
		
		usersSmallIcon[2] = new JLabel();
		Image users3SmallIcon = new ImageIcon("user3.png").getImage();
        Image users3SmallImg = users3SmallIcon.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        usersSmallIcon[2].setIcon(new ImageIcon(users3SmallImg));
        usersSmallIcon[2].setBounds(500, 30, 40, 40);
		//contentPane.add(usersSmallIcon[2]);
		
		usersSmallIcon[3] = new JLabel();
		Image users4SmallIcon = new ImageIcon("user4.png").getImage();
        Image users4SmallImg = users4SmallIcon.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        usersSmallIcon[3].setIcon(new ImageIcon(users4SmallImg));
        usersSmallIcon[3].setBounds(500, 30, 40, 40);
		//contentPane.add(usersSmallIcon[3]);
		
        for(int i = 0; i < 3; i++) {
        	for (int j = 0; j < 20; j++) {
        		user1Building[i][j] = new JLabel();
        		user2Building[i][j] = new JLabel();
        		user3Building[i][j] = new JLabel();
        		user4Building[i][j] = new JLabel();
        	}
        }
        
		ImageIcon user1villa = new ImageIcon("user1villa.png");
		ImageIcon user1building = new ImageIcon("user1building.png");
		ImageIcon user1hotel = new ImageIcon("user1hotel.png");
        
		ImageIcon user2villa = new ImageIcon("user2villa.png");
		ImageIcon user2building = new ImageIcon("user2building.png");
		ImageIcon user2hotel = new ImageIcon("user2hotel.png");
        
		ImageIcon user3villa = new ImageIcon("user3villa.png");
		ImageIcon user3building = new ImageIcon("user3building.png");
		ImageIcon user3hotel = new ImageIcon("user3hotel.png");
        
		ImageIcon user4villa = new ImageIcon("user4villa.png");
		ImageIcon user4building = new ImageIcon("user4building.png");
		ImageIcon user4hotel = new ImageIcon("user4hotel.png");
		

		
		for (int j = 0; j < 20; j++) {
			user1Building[0][j].setIcon(user1villa);
			user1Building[1][j].setIcon(user1building);
			user1Building[2][j].setIcon(user1hotel);
			user2Building[0][j].setIcon(user2villa);
			user2Building[1][j].setIcon(user2building);
			user2Building[2][j].setIcon(user2hotel);
			user3Building[0][j].setIcon(user3villa);
			user3Building[1][j].setIcon(user3building);
			user3Building[2][j].setIcon(user3hotel);
			user4Building[0][j].setIcon(user4villa);
			user4Building[1][j].setIcon(user4building);
			user4Building[2][j].setIcon(user4hotel);
    	}
        
		dice1 = new JLabel();
		dice1.setBounds(120, 100, 70, 70);
		
		dice2 = new JLabel();
		dice2.setBounds(200, 100, 70, 70);
		
		buyVilla = new JButton();
		ImageIcon btnVilla = new ImageIcon("btnVilla.png");
		buyVilla.setIcon(btnVilla);
		buyVilla.setBounds(120, 120, 202, 202);
		//contentPane.add(buyVilla);
		
		buyVillaPrice = new JLabel();
		buyVillaPrice.setHorizontalAlignment(JLabel.CENTER);
		buyVillaPrice.setFont(buyVillaPrice.getFont().deriveFont (20.0f));
		buyVillaPrice.setBounds(125, 325, 200, 30);
		
		buyBuilding = new JButton();
		ImageIcon btnBuilding = new ImageIcon("btnBuilding.png");
		buyBuilding.setIcon(btnBuilding);
		buyBuilding.setBounds(340, 120, 202, 202);
		//contentPane.add(buyBuilding);
		
		buyBuildingPrice = new JLabel();
		buyBuildingPrice.setHorizontalAlignment(JLabel.CENTER);
		buyBuildingPrice.setFont(buyBuildingPrice.getFont().deriveFont (20.0f));
		buyBuildingPrice.setBounds(350, 325, 200, 30);
		
		buyHotel = new JButton();
		ImageIcon btnHotel = new ImageIcon("btnHotel.png");
		buyHotel.setIcon(btnHotel);
		buyHotel.setBounds(560, 120, 202, 202);
		//contentPane.add(buyHotel);
		
		buyHotelPrice = new JLabel();
		buyHotelPrice.setHorizontalAlignment(JLabel.CENTER);
		buyHotelPrice.setFont(buyHotelPrice.getFont().deriveFont (20.0f));
		buyHotelPrice.setBounds(565, 325, 200, 30);
		
		buyCancel = new JButton();
		ImageIcon btnCancel = new ImageIcon("btnCancel.png");
		buyCancel.setIcon(btnCancel);
		buyCancel.setBounds(280, 355, 319, 55);
		//contentPane.add(buyCancel);
		
		
		btnChBg = new JButton();
		ImageIcon btnChBgIcon = new ImageIcon("btnChBg.png");
		btnChBg.setIcon(btnChBgIcon);
		btnChBg.setBounds(630, 510, 100, 40);
		contentPane.add(btnChBg);
		
		btnLeave = new JButton();
		ImageIcon btnLeaveIcon = new ImageIcon("btnLeave2.png");
		btnLeave.setIcon(btnLeaveIcon);
		btnLeave.setBounds(750, 510, 100, 40);
		contentPane.add(btnLeave);
		
		btnRoll = new JButton();
		ImageIcon btnRollIcon = new ImageIcon("btnRoll.png");
		btnRoll.setIcon(btnRollIcon);
		btnRoll.setBounds(630, 430, 220, 70);
		contentPane.add(btnRoll);

		//AppendText("User " + username + " connecting " + ip_addr + " " + port_no);
		UserName = username;
		
		try {
			socket = new Socket(ip_addr, Integer.parseInt(port_no));
			is = socket.getInputStream();
			dis = new DataInputStream(is);
			os = socket.getOutputStream();
			dos = new DataOutputStream(os);
			
			
			SendMessage("/login " + UserName + " " + location.getVillaPrice());
			ListenNetwork net = new ListenNetwork();
			net.start();
			Myaction action = new Myaction();
			btnSend.addActionListener(action); // ����Ŭ������ �׼� �����ʸ� ��ӹ��� Ŭ������
			txtInput.addActionListener(action);
			txtInput.requestFocus();
			btnLeave.addActionListener(action);
			btnChBg.addActionListener(action);
			btnRoll.addActionListener(action);
			buyVilla.addActionListener(action);
			buyBuilding.addActionListener(action);
			buyHotel.addActionListener(action);
			buyCancel.addActionListener(action);
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			AppendText("connect error");
		}

	}
	// Server Message�� �����ؼ� ȭ�鿡 ǥ��
	class ListenNetwork extends Thread {
		public void run() {
			while (true) {
				try {
					// String msg = dis.readUTF();
					byte[] b = new byte[BUF_LEN];
					int ret;
					ret = dis.read(b);
					if (ret < 0) {
						AppendText("dis.read() < 0 error");
						try {
							dos.close();
							dis.close();
							socket.close();
							break;
						} catch (Exception ee) {
							break;
						}// catch�� ��
					}
					String	msg = new String(b, "euc-kr");
					msg = msg.trim(); // �յ� blank NULL, \n ��� ����
					AppendText(msg); // server ȭ�鿡 ���
				} catch (IOException e) {
					AppendText("dis.read() error");
					try {
						dos.close();
						dis.close();
						socket.close();
						break;
					} catch (Exception ee) {
						break;
					} // catch�� ��
				} // �ٱ� catch����
				
			}
		}
	}
	// keyboard enter key ġ�� ������ ����
	class Myaction implements ActionListener // ����Ŭ������ �׼� �̺�Ʈ ó�� Ŭ����
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			// Send button�� �����ų� �޽��� �Է��ϰ� Enter key ġ��
			if (e.getSource() == btnSend || e.getSource() == txtInput) {
				String msg = null;
				msg = String.format("[%s] %s\n", UserName, txtInput.getText());
				SendMessage(msg);
				txtInput.setText(""); // �޼����� ������ ���� �޼��� ����â�� ����.
				txtInput.requestFocus(); // �޼����� ������ Ŀ���� �ٽ� �ؽ�Ʈ �ʵ�� ��ġ��Ų��
				//if (msg.contains("/exit")) // ���� ó��
				//	System.exit(0);
			}
			if(e.getSource() == btnChBg) {
				frame = new Frame("�̹���÷��");
				fd = new FileDialog(frame, "�̹��� ����", FileDialog.LOAD);
				// frame.setVisible(true);
				// fd.setDirectory(".\\");
				fd.setVisible(true);
				//System.out.println(fd.getDirectory() + fd.getFile());
				ChatMsg obcm = new ChatMsg(UserName, "300", "IMG");
				ImageIcon img = new ImageIcon(fd.getDirectory() + fd.getFile());
				obcm.setImg(img);
				SendObject(obcm);
			}
			if (e.getSource() == btnLeave) {
				System.exit(0);
			}
			if(e.getSource() == btnRoll) {
				String msg = null;
				msg = String.format("[%s] %s\n", UserName, "/roll");
				SendMessage(msg);
				if (msg.contains("/exit")) // ���� ó��
					System.exit(0);
			}
			if(e.getSource() == buyVilla || e.getSource() == buyBuilding || e.getSource() == buyHotel || e.getSource() == buyCancel) {
				
				if(e.getSource() == buyVilla) {
					SendMessage(UserName+ " /money -" + location.villaPrice);
				}
				else if(e.getSource() == buyBuilding) {
					SendMessage(UserName+ " /money -" + location.buildingPrice);
				}
				else if(e.getSource() == buyHotel) {
					SendMessage(UserName+ " /money -" + location.hotelPrice);
				}
				else {
					contentPane.remove(buyVilla);
					contentPane.remove(buyBuilding);
					contentPane.remove(buyHotel);
					contentPane.remove(buyVillaPrice);
					contentPane.remove(buyBuildingPrice);
					contentPane.remove(buyHotelPrice);
					contentPane.remove(buyCancel);
					
					repaint();
				}
			}
		}
	}
	// ȭ�鿡 ���
	public void AppendText(String msg) {
		if (msg.contains("/roll")) {
			MoveChara(msg);
		} else if (msg.contains("/setStart")) {
			SetStart(msg);
		} else if (msg.contains("/setAll")){
			SetAll(msg);
		} else if (msg.contains("/askBuy")){
			AskBuy(msg);
		} else if (msg.contains("/buy")){
			BuyBuilding(msg);
		} else if (msg.contains("/money")){
			GetOrGiveMoney(msg);
		} else if (msg.contains("/noMoney")){
			GetOrGiveMoney(msg);
		} else if (msg.contains("/exit")){
			System.exit(0);
		}
		else {
			textArea.append(msg + "\n");
			textArea.setCaretPosition(textArea.getText().length());
		}
	}

	// Windows ó�� message ������ ������ �κ��� NULL �� ����� ���� �Լ�
	public byte[] MakePacket(String msg) {
		byte[] packet = new byte[BUF_LEN];
		byte[] bb = null;
		int i;
		for (i = 0; i < BUF_LEN; i++)
			packet[i] = 0;
		try {
			bb = msg.getBytes("euc-kr");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
		for (i = 0; i < bb.length; i++)
			packet[i] = bb[i];
		return packet;
	}

	// Server���� network���� ����
	public void SendMessage(String msg) {
		try {
			// dos.writeUTF(msg);
			byte[] bb;
			bb = MakePacket(msg);
			dos.write(bb, 0, bb.length);
		} catch (IOException e) {
			AppendText("dos.write() error");
			try {
				dos.close();
				dis.close();
				socket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.exit(0);
			}
		}
	}
	
	public void SendObject(Object ob) { // ������ �޼����� ������ �޼ҵ�
		try {
			oos.writeObject(ob);
		} catch (IOException e) {
			// textArea.append("�޼��� �۽� ����!!\n");
			AppendText("SendObject Error");
		}
	}
	
	public void SetStart(String msg) {
		String msgs[] = msg.split("\n");
		String userWhere[];
		userWhere = msgs[msgs.length - 1].split("\t");
		UserName = userWhere[0];
	}
	
	public void SetAll(String msg) {
		String msgs[] = msg.split("\n");
		String userWhere[];
		for(int i = 1; i < msgs.length; i++) {
			if(msgs[i] != null) {
				userWhere = msgs[i].split("\t");
				lblUserName[i-1].setText(userWhere[0]);
				contentPane.add(lblUserName[i-1]);
				
				cityLocation = new CityLocation();
				location = cityLocation.getCity(Integer.parseInt(userWhere[1]));
				usersSmallIcon[i-1].setBounds(location.x, location.y, 40, 40);
				contentPane.add(usersSmallIcon[i-1]);
				contentPane.add(usersIcon[i-1]);
				contentPane.add(usersMoney[i-1]);
				contentPane.add(usersCard[i-1]);
				repaint();
			}
		}
	}
	
	public void BuyBuilding(String msg) {
		System.out.println(msg);
		String msgs[] = msg.split(" ");
		if (msg.contains("-" + Integer.toString(location.villaPrice))){
			if (msgs[0].contains("User1")) {
				user1Building[0][building1Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user1Building[0][building1Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User2")) {
				user2Building[0][building2Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user2Building[0][building2Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User3")) {
				user3Building[0][building3Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user3Building[0][building3Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User4")) {
				user4Building[0][building4Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user4Building[0][building4Cnt++]);
				
				repaint();
				
			}
			SendMessage(msgs[0] + " /checkBuy " + location.villaPrice);
		}
		else if (msg.contains(Integer.toString(location.buildingPrice)) && location.isCanBuy()){
			if (msgs[0].contains("User1")) {
				user1Building[1][building1Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user1Building[1][building1Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User2")) {
				user2Building[1][building2Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user2Building[1][building2Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User3")) {
				user3Building[1][building3Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user3Building[1][building3Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User4")) {
				user4Building[1][building4Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user4Building[1][building4Cnt++]);
				
				repaint();
			}
			SendMessage(msgs[0] + " /checkBuy " + location.buildingPrice);
		}
		else if (msg.contains(Integer.toString(location.hotelPrice)) && location.isCanBuy()){
			if (msgs[0].contains("User1")) {
				user1Building[2][building1Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user1Building[2][building1Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User2")) {
				user2Building[2][building2Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user2Building[2][building2Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User3")) {
				user3Building[2][building3Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user3Building[2][building3Cnt++]);
				
				repaint();
			}
			else if (msgs[0].contains("User4")) {
				user4Building[2][building4Cnt].setBounds(location.x, location.y+5, 30, 30);
				contentPane.add(user4Building[2][building4Cnt++]);
				
				repaint();
			}
			SendMessage(msgs[0] + " /checkBuy " + location.hotelPrice);
		}
	}
	
	
	public void GetOrGiveMoney(String msg) {
		if(msg.contains("/noMoney")) {
			if (msg.contains(Integer.toString(location.villaPrice))){
				buyVillaPrice.setText("���� �����մϴ�!");
				buyVillaPrice.setForeground(Color.RED);
				contentPane.add(buyVillaPrice);
			}
			else if (msg.contains(Integer.toString(location.buildingPrice))){
				buyBuildingPrice.setText("���� �����մϴ�!");
				buyBuildingPrice.setForeground(Color.RED);
				contentPane.add(buyBuildingPrice);
			}
			else if (msg.contains(Integer.toString(location.hotelPrice))){
				buyHotelPrice.setText("���� �����մϴ�!");
				buyHotelPrice.setForeground(Color.RED);
				contentPane.add(buyHotelPrice);
			}
			else {
				SendMessage("/exit");
			}
					
		}
		else {
			String msgs[] = msg.split("\n");
			String userMoney[];
			for(int i = 1; i < msgs.length; i++) {
				if(msgs[i] != null) {
					userMoney = msgs[i].split("\t");
					usersMoney[i-1].setText("�ڻ�: " + userMoney[1]);
					contentPane.add(usersMoney[i-1]);
					contentPane.remove(buyVilla);
					contentPane.remove(buyBuilding);
					contentPane.remove(buyHotel);
					contentPane.remove(buyVillaPrice);
					contentPane.remove(buyBuildingPrice);
					contentPane.remove(buyHotelPrice);
					contentPane.remove(buyCancel);
				}
			}
		}
		repaint();
	}
	
	public void MoveChara(String msg) {

		ImageIcon dice1Img = new ImageIcon("dice1.png");
		ImageIcon dice2Img = new ImageIcon("dice2.png");
		ImageIcon dice3Img = new ImageIcon("dice3.png");
		ImageIcon dice4Img = new ImageIcon("dice4.png");
		ImageIcon dice5Img = new ImageIcon("dice5.png");
		ImageIcon dice6Img = new ImageIcon("dice6.png");
		
		String msgs[] = msg.split(" ");	
		if (Integer.parseInt(msgs[3]) == 1) {
			dice1.setIcon(dice1Img);
			contentPane.add(dice1);
			repaint();
		}
		if (Integer.parseInt(msgs[3]) == 2) {
			dice1.setIcon(dice2Img);
			contentPane.add(dice1);
			repaint();
		}
		if (Integer.parseInt(msgs[3]) == 3) {
			dice1.setIcon(dice3Img);
			contentPane.add(dice1);
			repaint();
		}
		if (Integer.parseInt(msgs[3]) == 4) {
			dice1.setIcon(dice4Img);
			contentPane.add(dice1);
			repaint();
		}
		if (Integer.parseInt(msgs[3]) == 5) {
			dice1.setIcon(dice5Img);
			contentPane.add(dice1);
			repaint();
		}
		if (Integer.parseInt(msgs[3]) == 6) {
			dice1.setIcon(dice6Img);
			contentPane.add(dice1);
			repaint();
		}

		if (Integer.parseInt(msgs[4]) == 1) {
			dice2.setIcon(dice1Img);
			contentPane.add(dice2);
			repaint();
		}
		if (Integer.parseInt(msgs[4]) == 2) {
			dice2.setIcon(dice2Img);
			contentPane.add(dice2);
			repaint();
		}
		if (Integer.parseInt(msgs[4]) == 3) {
			dice2.setIcon(dice3Img);
			contentPane.add(dice2);
			repaint();
		}
		if (Integer.parseInt(msgs[4]) == 4) {
			dice2.setIcon(dice4Img);
			contentPane.add(dice2);
			repaint();
		}
		if (Integer.parseInt(msgs[4]) == 5) {
			dice2.setIcon(dice5Img);
			contentPane.add(dice2);
			repaint();
		}
		if (Integer.parseInt(msgs[4]) == 6) {
			dice2.setIcon(dice6Img);
			contentPane.add(dice2);
			repaint();
		}
		
		cityLocation = new CityLocation();
		location = cityLocation.getCity(Integer.parseInt(msgs[2]));
		AppendText(location.cityName + "����!");
		
		for(int i = 0; i < 4; i++) {
			if (msgs[0].contains("User" + (i+1))) {
		        usersSmallIcon[i].setBounds(location.x, location.y, 40, 40);
				contentPane.add(usersSmallIcon[i]);
				repaint();
			}
		}
		/*
		if(location.isCanBuy()) {
			AppendText(location.cityName + "����! ������ " + location.villaPrice + "��!");
			buyVillaPrice.setText(location.villaPrice + "��");
			buyVillaPrice.setForeground(Color.BLACK);
			buyBuildingPrice.setText(location.buildingPrice + "��");
			buyBuildingPrice.setForeground(Color.BLACK);
			buyHotelPrice.setText(location.hotelPrice + "��");
			buyHotelPrice.setForeground(Color.BLACK);
			contentPane.add(buyVillaPrice);
			contentPane.add(buyBuildingPrice);
			contentPane.add(buyHotelPrice);
			contentPane.add(buyVilla);
			contentPane.add(buyBuilding);
			contentPane.add(buyHotel);
			contentPane.add(buyCancel);
			
			repaint();
		}
		else {
			SendMessage(UserName+ " /money -" + location.landPrice);
		}*/
		
	}
	
	public void AskBuy(String msg) {
		
		String msgs[] = msg.split(" ");
		location = cityLocation.getCity(Integer.parseInt(msgs[3]));
		
		if(Boolean.parseBoolean(msgs[2])) {
			buyVillaPrice.setText(location.getVillaPrice() + "��");
			buyVillaPrice.setForeground(Color.BLACK);
			buyBuildingPrice.setText(location.getBuildingPrice() + "��");
			buyBuildingPrice.setForeground(Color.BLACK);
			buyHotelPrice.setText(location.getHotelPrice() + "��");
			buyHotelPrice.setForeground(Color.BLACK);
			contentPane.add(buyVillaPrice);
			contentPane.add(buyBuildingPrice);
			contentPane.add(buyHotelPrice);
			contentPane.add(buyVilla);
			contentPane.add(buyBuilding);
			contentPane.add(buyHotel);
			contentPane.add(buyCancel);
			
			repaint();
		}
		else {
			SendMessage(UserName+ " /money -" + location.landPrice);
		}
	}
}
